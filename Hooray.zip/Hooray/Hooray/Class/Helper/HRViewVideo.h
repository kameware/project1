//
//  HRViewVideo.h
//  Hooray
//
//  Created by cncsoft on 4/11/13.
//  Copyright (c) 2013 Luan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HRViewVideo : UIView

@property (retain, nonatomic) IBOutlet UILabel *videoNameLabel;
@end
