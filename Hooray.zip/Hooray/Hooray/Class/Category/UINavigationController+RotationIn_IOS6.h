//
//  UINavigationController+RotationIn_IOS6.h
//  LinkDenity
//
//  Created by cncsoft on 4/2/13.
//  Copyright (c) 2013 cncsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UINavigationController+RotationIn_IOS6.h"
@interface UINavigationController (RotationIn_IOS6)

@end
