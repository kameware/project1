//
//  HRSplashView.h
//  Hooray
//
//  Created by luan on 4/12/13.
//  Copyright (c) 2013 Luan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "THLabel.h"
@interface HRSplashView : UIViewController

@property (retain, nonatomic) IBOutlet THLabel *nameAppLabel;
@property (retain, nonatomic) IBOutlet THLabel *animalLabel;
@property (retain, nonatomic) IBOutlet THLabel *hoorayLabel;
@end
