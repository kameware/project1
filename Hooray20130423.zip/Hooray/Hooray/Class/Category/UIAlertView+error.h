//
//  UIAlertView+error.h
//  iReporter
//
//  Created by Marin Todorov on 09/02/2012.
//  Copyright (c) 2012 Marin Todorov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIAlertView(error)

+(void)error:(NSString*)msg;

@end
